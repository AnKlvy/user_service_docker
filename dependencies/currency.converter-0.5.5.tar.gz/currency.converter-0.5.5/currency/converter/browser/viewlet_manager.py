from zope.viewlet.interfaces import IViewletManager

class ICurrencyConverter(IViewletManager):
    """A viewlet manager of currency converter in order.
    """
